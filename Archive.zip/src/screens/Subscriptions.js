
import React, { Component } from "react";
import { View, TouchableOpacity,Image, Text, FlatList, Dimensions,ActivityIndicator,Linking } from "react-native";
import Moment from 'moment'
import AsyncStorage from '@react-native-async-storage/async-storage'

import { API_ROOT, IMG_PREFIX_URL} from "../config/constant";
import { Height, Width } from "../config/dimensions";
import { isRequired } from "react-native/Libraries/DeprecatedPropTypes/DeprecatedColorPropType";
import strings from '../config/LanguageStrings'

const icback = require("../../assets/images/ic_back.png");
const defaultuser = require("../../assets/images/ic_default_user_black.png");


let deviceWidth = Dimensions.get('window').width

class Subscriptions extends Component
{
    constructor (props)
    {
        super(props);
        this.state = {
            arrsubscriptions:[{'Type':strings.FreeAccount,'PriceMonth':'0','PriceYear':'0','Features':strings.SubFeatures},{'Type':strings.BasicAccount,'PriceMonth':'6','PriceYear':'50','Features':strings.FeaturesBasic},{'Type':strings.VipAccount,'PriceMonth':'20','PriceYear':'200','Features':strings.FeatureVIP}],
            user_id:'',
            showloading:false,
            is_from_settings:props.navigation.state.params.is_from_settings
        }
    //     this._didFocusSubscription = props.navigation.addListener('didFocus', payload => {
    //         this.loadData()
    //    });
    }

    async componentDidMount()
    {
        await AsyncStorage.getItem('user_id').then((value)=>{
            this.setState({user_id:value})
          });

    }
    
    // loadData()
    // {
        
    // }

    onMenuPressed()
    {
        this.props.navigation.navigate('App')
    }

    onBackPressed()
    {
        this.props.navigation.goBack()
    }

    onPressedVisitWeb()
    {
        Linking.openURL("https://www.thejoblamp.com")
    }

    renderTopBar()
    {
        return (
            <View style = {{backgroundColor:'#c80025', height:80, width:'100%', flexDirection:'row', justifyContent:'center'}}>
                    {
                        this.state.is_from_settings == true ?
                        <TouchableOpacity style={{position:'absolute',left:15,marginTop:45,height:25,width:25,justifyContent:'center'}} onPress={() => this.onBackPressed()}>
                            <Image source = {icback} resizeMode= 'contain'/>
                        </TouchableOpacity>
                        :

                        <TouchableOpacity style={{position:'absolute',right:15,marginTop:45,height:25,width:25,justifyContent:'center', width:100,alignItems:'flex-end'}} onPress={() => this.onMenuPressed()}>
                            <Text style={{color:'#fff',fontSize:20,fontWeight:'600'}}>{strings.Skip}</Text>
                        </TouchableOpacity>
                    }
                    
                    <Text style = {{marginTop:45, width:'30%', height:35,textAlign:'center', color:'#fff', fontSize:20, fontWeight:'600'}}>{strings.Subscriptions}</Text>
            </View>
        );
    }

    render(){
        return(
            <View style = {{flex:1,backgroundColor:'#f0f0f0'}}>
                {this.renderTopBar()}
                {
                    this.state.showloading == true ?
                    <View style = {{alignItems:'center',justifyContent:'center',backgroundColor:'transparent', zIndex:2, width:Width(100), height:Height(100) , position:'absolute'}}>
                        <ActivityIndicator size="large" color="#c80025"/>
                    </View>
                    : null
                }
                <View style = {{width:'100%',flex:1}}>
                    <FlatList
                        showsHorizontalScrollIndicator={false}
                        data={this.state.arrsubscriptions}
                        ref={(ref) => { this.scroll = ref; }}
                        renderItem={({ item,index }) => {
                            return (
                                    <TouchableOpacity style={{ borderRadius: 5,padding: 5,backgroundColor: 'transparent', alignItems:'center'}} activeOpacity = {0.9}>
                                        <View style = {{backgroundColor:'#fff', width:deviceWidth - 30,borderRadius:10, paddingVertical:10, alignItems:'center'}}>
                                            <View style = {{width:'90%',justifyContent:'center'}}>
                                                <Text style = {{fontSize:18,fontWeight:'500'}}>{item.Type}</Text>
                                                <View style = {{height:40,width:'100%',borderRadius:7, alignItems:'center',justifyContent:'space-around', flexDirection:'row', alignSelf:'center', marginTop:10}}>
                                                    <View style = {{height:40,width:Width(40),borderRadius:7,backgroundColor:'#fcf3f3', alignItems:'center'}}>
                                                        <Text style = {{fontSize:17,fontWeight:'600', marginTop:10,color:'#c80025'}}>${item.PriceMonth}/{strings.month}</Text>
                                                    </View>
                                                    <View style = {{height:40,width:Width(40),borderRadius:7,backgroundColor:'#fcf3f3', alignItems:'center'}}>
                                                        <Text style = {{fontSize:17,fontWeight:'600', marginTop:10,color:'#c80025'}}>${item.PriceYear}/{strings.year}</Text>
                                                    </View>
                                                </View>
                                                <Text style = {{fontSize:15,fontWeight:'400', marginTop:10}}>{strings.FeaturesOf} {item.Type}</Text>
                                                <Text style = {{fontSize:15,fontWeight:'300',color:'3e3e3e', marginTop:10}}>{item.Features}</Text>
                                                <TouchableOpacity style = {{height:40,width:Width(80),borderRadius:7,backgroundColor:'#c80025', alignItems:'center', marginTop:20,justifyContent:'center'}} onPress = { () => this.onPressedVisitWeb()}>
                                                        <Text style = {{fontSize:20,fontWeight:'400',color:'#fff'}}>{strings.VisitWeb}</Text>
                                                </TouchableOpacity>
                                                {/* <Text style={{fontSize: 10,color: '#6e6e6e',fontWeight: '500',textAlign:'left',marginBottom:7,marginTop:7,fontSize:15}} numberOfLines = {1}>{item.receiver.first_name} {item.receiver.last_name}</Text> */}
                                            </View>
                                        </View>
                                    </TouchableOpacity>
                                    );        
                                }}
                        keyExtractor={(item, index) => index}
                    />
                </View>
            </View>
        )
    }

}
export default Subscriptions;
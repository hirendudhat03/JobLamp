// export const MAIN_ROOT = "http://joblamp.mobilesmartdev.in/"
// export const API_ROOT = "http://joblamp.mobilesmartdev.in/api/"
// export const IMG_PREFIX_URL = "http://joblamp.mobilesmartdev.in/public/";
// export const PROFILE_PIC_PREFIX ="";
// export const AWS_S3_URL ="https://thejoblampbucket.s3.eu-west-1.amazonaws.com/";
//http://hcuboidtech.com/joblamp/public/api/

export const MAIN_ROOT = "http://hcuboidtech.com/"
export const API_ROOT = "http://hcuboidtech.com/joblamp/public/api/"
export const IMG_PREFIX_URL = "http://hcuboidtech.com/joblamp/public/";
export const PROFILE_PIC_PREFIX ="";

// export const MAIN_ROOT = "https://thejoblamp.com/"
// export const API_ROOT = "https://thejoblamp.com/api/"
// export const IMG_PREFIX_URL = "https://thejoblamp.com/public/";
// export const PROFILE_PIC_PREFIX ="";